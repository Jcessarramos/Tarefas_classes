package Loja;

public class Caixa {
	 
}
