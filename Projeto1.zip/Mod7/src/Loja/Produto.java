package Loja;

public class Produto {
	 
	private String Nome;  
	private int Caixa ; 
}
