package Loja;

public class Cliente {
	private String Nome; 
	private String Produto ; 
	private int Caixa ;
	
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		
		this.Nome = nome;
	}
	public String getProduto() {
		return Produto;
	}
	public void setProduto(String produto) {
		Produto = produto;
	}
	public int getCaixa() {
		return Caixa;
	}
	public void setCaixa(int caixa) {
		Caixa = caixa;
	} 
	
	public void getNome ( String Nome ) {
		this.Nome = Nome ; 
		
	}
	public void digiteSeuNome (String Nome ) {
		setNome(Nome); 
		
	}
	public void getCaixa (String caixa ) {
		this
	}
	
}
