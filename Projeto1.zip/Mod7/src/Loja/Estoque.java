package Loja;

public class Estoque {
	private int Quantidade; 
	private String Nome; 

	
}
