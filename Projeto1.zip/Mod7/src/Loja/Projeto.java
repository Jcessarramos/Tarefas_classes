package Loja;

public class Projeto {
public static void main(String[] args) {
    Cliente cliente = new Cliente () ; 
    cliente.digiteSeuNome("Júlio");
    System.out.println(cliente.getNome());
    Cliente.
}
}
//Esse é o meu projetinho, espero que gostem!